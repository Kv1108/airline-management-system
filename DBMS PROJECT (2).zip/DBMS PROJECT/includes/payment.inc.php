<?php
session_start();
use PHPMailer\PHPMailer\PHPMailer;

if(isset($_POST['pay_but']) && isset($_SESSION['userId'])) {
    require '../helpers/init_conn_db.php';  

    // Extract session variables
    $flight_id = $_SESSION['flight_id'];
    $price = $_SESSION['price'];
    $passengers = $_SESSION['passengers'];
    $pass_id = $_SESSION['pass_id'];
    $type = $_SESSION['type'];
    $class = $_SESSION['class'];
    $ret_date = $_SESSION['ret_date'];
    $card_no = $_POST['cc-number'];
    $expiry = $_POST['cc-exp'];  

    // Insert payment record
    $sql = 'INSERT INTO PAYMENT (user_id, expire_date, amount, flight_id, card_no) 
            VALUES (?, ?, ?, ?, ?)';            
    $stmt = mysqli_stmt_init($conn);
    if(!mysqli_stmt_prepare($stmt, $sql)) {
        header('Location: ../payment.php?error=sqlerror');
        exit();            
    } else {
        mysqli_stmt_bind_param($stmt, 'isiis', $_SESSION['userId'], $expiry, $price, $flight_id, $card_no);          
        mysqli_stmt_execute($stmt);
    }

    // Insert ticket records
    $flag = false;
    for($i = $pass_id; $i <= $passengers + $pass_id; $i++) {
        $sql = 'INSERT INTO Ticket (passenger_id, flight_id, seat_no, cost, class, user_id)
                VALUES (?, ?, ?, ?, ?, ?)';            
        if(!mysqli_stmt_prepare($stmt, $sql)) {
            header('Location: ../payment.php?error=sqlerror');
            exit();            
        } else {
            // Generate new seat number
            $new_seat = generateSeatNumber($conn, $flight_id, $class);

            // Insert ticket record
            mysqli_stmt_bind_param($stmt, 'iisisi', $i, $flight_id, $new_seat, $price, $class, $_SESSION['userId']);            
            mysqli_stmt_execute($stmt);  
            $flag = true;
        }                                                                       
    } 

    // Handle round trip flights
    if($type === 'round' && $flag) {
        $flag = false;
        for($i = $pass_id; $i <= $passengers + $pass_id; $i++) {
            // Retrieve return flight details
            $sql = 'SELECT * FROM Flight WHERE source = ? AND Destination = ? AND DATE(departure) = ?';
            if(!mysqli_stmt_prepare($stmt, $sql)) {
                header('Location: ../payment.php?error=sqlerror');
                exit();            
            } else {
                mysqli_stmt_bind_param($stmt, 'sss', $dest, $source, $ret_date);            
                mysqli_stmt_execute($stmt);
                $result = mysqli_stmt_get_result($stmt);
                if($row = mysqli_fetch_assoc($result)) {                        
                    $flight_id = $row['flight_id'];

                    // Generate new seat number
                    $new_seat = generateSeatNumber($conn, $flight_id, $class);

                    // Insert ticket record
                    mysqli_stmt_bind_param($stmt, 'iisisi', $i, $flight_id, $new_seat, $price, $class, $_SESSION['userId']);            
                    mysqli_stmt_execute($stmt);  
                    $flag = true;
                } else {
                    header('Location: ../payment.php?error=noret');
                    exit();                     
                }
            }   
        }             
    }

    // Redirect based on success or failure
    if($flag) {
        // Unset session variables
        unset($_SESSION['flight_id']);
        unset($_SESSION['passengers']);
        unset($_SESSION['pass_id']);
        unset($_SESSION['price']);
        unset($_SESSION['class']);    
        unset($_SESSION['type']);     
        unset($_SESSION['ret_date']);               
        header('Location: ../pay_success.php');
        exit();    
    } else {
        header('Location: ../payment.php?error=sqlerror');
        exit();               
    }

    mysqli_stmt_close($stmt);
    mysqli_close($conn);        

} else {
    header('Location: ../payment.php');
    exit();  
}    

// Function to generate seat number based on class
function generateSeatNumber($conn, $flight_id, $class) {
    $sql = 'SELECT * FROM Flight WHERE flight_id = ?';
    $stmt = mysqli_stmt_init($conn);
    if(!mysqli_stmt_prepare($stmt, $sql)) {
        header('Location: ../payment.php?error=sqlerror');
        exit();            
    } else {
        mysqli_stmt_bind_param($stmt, 'i', $flight_id);            
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        if($row = mysqli_fetch_assoc($result)) {
            if($class === 'B') {
                $seat_column = 'last_bus_seat';
            } else {
                $seat_column = 'last_seat';
            }

            if($row[$seat_column] === '') {
                $new_seat = ($class === 'B') ? '1A' : '21A';
            } else {
                $last_seat = $row[$seat_column];
                $ls_len = strlen($last_seat);
                $seat_num = (int)substr($last_seat, 0, $ls_len - 1);
                $seat_alpha = $last_seat[$ls_len - 1];
                if($seat_alpha === 'F') {
                    $seat_num++;
                    $seat_alpha = 'A';
                } else {
                    $seat_alpha = chr(ord($seat_alpha) + 1);
                }
                $new_seat = $seat_num . $seat_alpha;
            }
            return $new_seat;
        } else {
            header('Location: ../payment.php?error=sqlerror');
            exit();                     
        }
    }
}
?>
